<h3>Libro más vendido</h3>
<h3>{{$masvendido->name }}</h3>
<h3>{{$masvendido->qty}}</h3>


