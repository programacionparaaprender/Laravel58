<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //luiscorrea13711
        //luiscorrea1820
        EditorialWeb\User::create([
            'name' => 'Luis Correa',
            'email' => 'alberto13711@gmail.com',
            'password' => bcrypt('luiscorrea13711'),
            'estado' => 1
        ]);
    }
}
