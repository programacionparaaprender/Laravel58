<?php $__env->startSection('content'); ?>
<div style="height:10rem;width:100%;display:block;"></div>
<div class="container-fluid">
<?php if(sizeof($representantes) > 0): ?>

<!--tabla de representante activo-->
<h1>Roles de usuario</h1>
<table class="table table-bordered">
<thead>
    <tr>
        <th>Nro </th>
        <th>Nombre</th>
        <th>Estado</th>
        <th>Actualizar</th>
    </tr>
</thead>
<tbody>
<?php $__currentLoopData = $representantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $representante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($representante->id); ?></td>
    <td><?php echo e($representante->name); ?></td>
      <form class="form-horizontal" role="form" action="<?php echo e(url('validado/representante/rol')); ?>" method="POST">
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" required>
          <input type="hidden" name="id" value="<?php echo e($representante->id); ?>" required>
          <div class="form-group required">

            <!--<div class="col-sm-3">-->
            <td>
            <select name="selector" required>
                <optgroup label="Roles">
                    <?php if($representante->estado==1): ?>
                    <option value="1" selected>Administrador</option>
                    <option value="2">Empleado</option>
                    <option value="3">Cliente</option>
                    <option value="0">Inactivo</option>
                    <?php elseif($representante->estado==2): ?>
                    <option value="1">Administrador</option>
                    <option value="2" selected>Empleado</option>
                    <option value="3">Cliente</option>
                    <option value="0">Inactivo</option>
                    <?php elseif($representante->estado==3): ?>
                    <option value="1">Administrador</option>
                    <option value="2">Empleado</option>
                    <option value="3" selected>Cliente</option>
                    <option value="0">Inactivo</option>
                    <?php else: ?>
                    <option value="1">Administrador</option>
                    <option value="2">Empleado</option>
                    <option value="3">Cliente</option>
                    <option value="0" selected>Inactivo</option>
                    <?php endif; ?>
                </optgroup>
            </select>
            <!--</div>-->
            </td>
          </div>
          <div class="form-group">
              <td>
              <button type="submit" class="btn btn-primary">
              Actualizar rol
              </button>
              </td>
        </div>
      </form>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

<?php else: ?>
<div class="alert alert-danger">
    <p>Al parecer no tiene representantes actualmente.</p>
</div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bus209\Documents\htdocs\LaravelGodaddy\resources\views/representante/roles.blade.php ENDPATH**/ ?>