<link rel="stylesheet" href="../css/bootstrap.min.css">
<script src=../js/bootstrap.min.js"></script>
<link rel="stylesheet" href="../css/bootstrap-theme.min.css">
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/jquery-2.2.3.min.js"></script>

<?php /**PATH C:\Users\Bus209\Documents\htdocs\LaravelApiMySQL\resources\views/layouts/bootstrap.blade.php ENDPATH**/ ?>