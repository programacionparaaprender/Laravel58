<?php $__env->startSection('content'); ?>
<div style="display:block;width:100%;height:5rem;">
		</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    Bienvenido <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->email); ?>

                    <div>
                        <a href="<?php echo e(url('/post/')); ?>">Ir a post</a>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bus209\Documents\htdocs\LaravelGodaddy\resources\views/home.blade.php ENDPATH**/ ?>