<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" type="image/x-icon" href="principal.ico">
	<title>Programación para aprender</title>
        <?php echo $__env->yieldContent('css'); ?>

        <!-- para bootstrap en archivos blade dentro de carpetas en views -->
        
    <!-- Estilos Bootstrap 4 -->	
	<link rel="stylesheet" href="<?php echo e(url('./css/bootstrap.css')); ?>">
    

</head>
<body>
<header class="container-fluid" style="font-style: italic;">
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
		<div class="container-fluid">
		
			<a class="navbar-brand" href="#/">
				<img src="<?php echo e(url('images/principal.jpg')); ?>" width="50" height="50" alt="">
			</a>
			
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menuprincipal" aria-controls="menuprincipal" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			
			<div class="collapse navbar-collapse" id="menuprincipal">
				<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="<?php echo e(url('/')); ?>">Inicio</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" aria-current="page" href="<?php echo e(url('libros/')); ?>">Productos</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" aria-current="page" href="<?php echo e(url('libros/')); ?>">Servicios</a>
					</li>
					
						<?php if(Auth::guest()): ?>
						<p></p>
						<?php else: ?>
						<?php if(Auth::user()->estado==1): ?>
						<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="<?php echo e(url('reportes/')); ?>">Reportes</a></li>
						<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="<?php echo e(url('pedidos/')); ?>">Pedidos</a></li>
						<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="<?php echo e(url('validado/registrar-empleado')); ?>">Registrar Empleados</a></li>
						<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="<?php echo e(url('validado/representante/rol')); ?>">Roles de usuario</a></li>
						<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="<?php echo e(url('carrito/')); ?>">Carrito</a>
						</li>
						<li class="nav-item">
						<a class="nav-link" aria-current="page" href="<?php echo e(url('/post/')); ?>">Posts</a>
						</li>
						<?php elseif(Auth::user()->estado==0): ?>
						<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="<?php echo e(url('carrito/')); ?>">Carrito</a></li>
						<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="<?php echo e(url('pedidos/')); ?>">Mis Pedidos</a>
						</li>
						<li class="nav-item">
						<a class="nav-link" aria-current="page" href="<?php echo e(url('/post/')); ?>">Posts</a>
						</li>
						<?php endif; ?>
						<?php endif; ?>
				</ul>
				
				<ul class="nav navbar-nav navbar-right">
						<?php if(Auth::guest()): ?>
						<li class="nav-item">
						<a class="nav-link" aria-current="page" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></li>
						<li class="nav-item">
						<a class="nav-link" aria-current="page"  href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a></li>
						<?php else: ?>
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							Cuenta
							</a>
							<div class="dropdown-menu" aria-labelledby="navbarDropdown">
								<a class="dropdown-item" href="<?php echo e(url('/validado/representante/editar-perfil')); ?>">
								Actualizar perfil
								</a>
								<a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                </a>
								<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
							</div>
						</li>
						
						<?php endif; ?>
				</ul>
				<!-- <form class="form-inline my-2 my-lg-0">
					<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
					<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
				</form> -->
			</div>
   		</div>
	</nav> 

</header>
<!-- <div style="height:100rem;display:block;"></div> -->
	<div id="workshop-list">
	<article id="w1" class="workshop workshop-left">
		<?php echo $__env->yieldContent('content'); ?>
	</article>
	<article id="w1" class="workshop workshop-right">
		<?php echo $__env->yieldContent('content2'); ?>
	</article>
	</div>
    <footer class="footer   py-2 text-xs-center text-light bg-dark">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-5">
				<h3>PRÓXIMOS CURSOS</h3>
				<ul id="next-workshops">
					<li><a href="/detail">Título del primer curso</a></li>
				</ul>
			</div>
			<div class="col-xs-12 col-sm-7 col-md-6 col-md-offset-1">
				<h3>NO TE PIERDAS NUESTRAS NOVEDADES</h3>
				<form id="subscribe-form" action="">
					<div class="row">
						<div class="col-xs-7 col-sm-8">
							<div class="form-group">
								<label class="sr-only" for="email">tu correo electrónico</label>
								<input type="text" id="email" name="email" class="form-control input-lg" placeholder="tu correo electrónico">
							</div>
						</div>
						<div class="col-xs-5 col-sm-4">
							<button class="btn btn-secondary btn-lg">SUSCRIBIRME</button>
						</div>
					</div>
				</form>
			</div>
			<div class="clearfix"></div>
			<div class="col-xs-12 col-sm-5">
				<h3>SOBRE LOS WORKSHOPS</h3>
				<p>Estos workshps son el resultado de la suma de la ilusión y esfuerzos de <a href="#">Empresa</a>, <a href="#">Empresa 2</a> y <a href="#">Persona</a></p>
				<p>Una apuesta diferente al panorama formativo nacional aunando workshops de primer nivel, impartidos por reconocidos profesionales con una experiencia de fin de semana, en un entorno diferente. </p>
			</div>
			<div class="col-xs-12 col-sm-7 col-md-6 col-md-offset-1">
				<h3>TE GUSTA? CORRE LA VOZ</h3>
				<p>Si te gusta esta filosofía de formación, o has acudido a uno de nuestros workshops y te hemos convencido, ayúdanos a promocionarlos por Internet para que otros puedan disfrutar de ellos:</p>
				<!-- Insertar addthis -->
			</div>
		</div>
	</div>
</footer>

     <!--Scripts-->
     <?php echo $__env->yieldContent('scripts'); ?>
     <!-- jQuery first, then Tether, then Bootstrap JS. -->
	<script src="<?php echo e(url('./js/jquery-1.12.4.min.js')); ?>"></script>
	<script src="<?php echo e(url('./js/bootstrap.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\Bus209\Documents\htdocs\LaravelGodaddy\resources\views/app.blade.php ENDPATH**/ ?>