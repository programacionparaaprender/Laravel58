<?php $__env->startSection('content'); ?>
<div style="display:block;width:100%;height:10rem;"></div>
<div class="container-fluid">
<?php if(sizeof($carrito) > 0): ?>
    <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $carro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($index%4 == 0): ?>
        <div class="row">
	<?php endif; ?>
	<div class="col-sm-6 col-md-3">
            <div class="thumbnail">
		<div class="caption">
                    <?php echo e($carro->name); ?>

                    <?php echo e($carro->qty); ?>

                    Bsf <?php echo e($carro->price*$carro->qty); ?>

                </div>
            </div>
        </div>
        <?php if(($index+1)%4 == 0): ?>
	</div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <h3>Total a pagar Bsf <?php echo e($total); ?></h3>

        <form action="carrito/procesar" method="GET">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" required>
            <input class="btn btn-success" role="button" type="submit" value="Realizar pedido"/>
        </form>
        <form action="carrito/destruir" method="GET">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" required>
            <input class="btn btn-danger" role="button" type="submit" value="Vaciar carrito"/>
        </form>
<?php else: ?>
<div class="alert alert-danger">
    <p>Al parecer aun no has elegido ningun libro para comprar.</p>
</div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bus209\Documents\htdocs\LaravelGodaddy\resources\views/carrito/mostrar-carrito.blade.php ENDPATH**/ ?>