<?php $__env->startSection('content'); ?>
<div style="display:block;width:100%;height:5rem;"></div>
<div class="card card-default" style="width:55rem;padding:1rem;">
    <div class="card-body">
        <div class="card-header"><h3 class="text-center">Formulario de Compras</h3></div>
        <?php if(sizeof($pedidos) > 0): ?>
        <table class="table table-bordered">
        <thead>
            <tr>
                <th scope="col">Nro</th>
                <th scope="col">Nombre y Apellido</th>
                <th scope="col">Estado del pedido</th>
                <th scope="col">Fecha</th>
                <th scope="col">Acciones</th>  
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($pedido->id); ?></th>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user->id == $pedido->idusers): ?>
            <td>
                <p><?php echo e($user->name); ?><?php echo e($user->email); ?></p>
            </td>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <td>
                        <?php if($pedido->idestado==1): ?>
                            EnEspera
                        <?php elseif($pedido->idestado==2): ?>
                            Pagado
                        <?php elseif($pedido->idestado==3): ?>
                            Enviado
                        <?php elseif($pedido->idestado==4): ?>
                            Devuelto
                        <?php endif; ?>
            </td>
            <td>
                    <?php echo e($pedido->created_at); ?>

            </td>
            <td>
                <div class="btn-group" role="group" aria-label="Basic example">
                    <a 
                        href="<?php echo e(url('pedidos/notificar',[$pedido->id])); ?>" 
                        class="btn btn-secondary" 
                        role="button" 
                        target="_blank">
                        Notificar pago    
                    </a>
                    <a 
                        href="<?php echo e(url('pedidos/factura',[$pedido->id])); ?>" 
                        class="btn btn-secondary" 
                        role="button" 
                        target="_blank">
                        Visualizar Factura
                    </a>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
        <?php else: ?>
        <div class="alert alert-danger">
            <p>Al parecer no tiene pedidos actualmente.</p>
        </div>
        <?php endif; ?>
     
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bus209\Documents\htdocs\Laravel58\resources\views/pedidos/compra.blade.php ENDPATH**/ ?>