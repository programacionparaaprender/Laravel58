<?php $__env->startSection('content'); ?>
<div style="display:block;width:100%;height:5rem;"></div>

<div class="card card-default">
    <div class="card-body">
        <div class="card-header"><h3 class="text-center">Reportes de productos</h3></div>
        <div id="containet-fluid">
            <a href="<?php echo e(url('reportes/pedidos')); ?>" class="btn btn-secondary" role="button" target="_blank">Visualizar Pedidos</a>
            <canvas id="mycanvas" width="0" height="0"></canvas>
            <script src="<?php echo e(url('/js/jquery-2.1.4.min.js')); ?>"></script>
            <script src="<?php echo e(url('/js/Chart.js')); ?>"></script>
            <script src="../js/Chart.min.js"></script>
            <?php if(sizeof($lineas) > 0): ?>
            <?php $__currentLoopData = $lineas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $linea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h3>Nombre <?php echo e($linea->nombre); ?></h3>
                <p>id libro <?php echo e($linea->idlibro); ?></p>
                <p>Cantidad <?php echo e($linea->cantidad); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <canvas id="chart-area" width="256" height="256"></canvas>
        </div>
    </div>
</div>
<script>
        var colores= ["orange","green","red","black","blue"];
        var contador=0;

        var pieData = [
                <?php if(sizeof($lineas) > 0): ?>
                <?php $__currentLoopData = $lineas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $linea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                    value:<?php echo e($linea->cantidad); ?>,
                    color:colores[contador++],
                    highlight: "red",
                    label: '<?php echo e($linea->nombre); ?>'
                    },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                {
                    value:40,
                    color:"orange",
                    highlight: "red",
                    label: "Primer dato"
                },
                {
                    value:60,
                    color:"#0b82e7",
                    highlight: "red",
                    label: "Segundo dato"
                }
                <?php endif; ?>
        ];
        var ctx = document.getElementById("chart-area").getContext("2d");
        window.myPie = new Chart(ctx).Pie(pieData);	
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bus209\Documents\htdocs\LaravelGodaddy\resources\views/reportes/masvendido.blade.php ENDPATH**/ ?>