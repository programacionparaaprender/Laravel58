<?php $__env->startSection('content'); ?>
<!-- Styles -->
<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<div class="container">
<h1>Editar post</h1>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<form action="<?php echo e(route('post.update', ['post' => $post->id])); ?>" method="post">
<?php echo method_field('PUT'); ?>
<?php echo csrf_field(); ?>
<label for="titulo">Título</label>
<input type="text" value="<?php echo e($post->titulo); ?>" class="form-control" id="titulo" name="titulo" />
<label for="contenido">Contenido</label>
<textarea name="contenido"  id="contenido" class="form-control">
<?php echo e($post->contenido); ?>

</textarea>
<label for="autor">Autor</label>
<select name="id_autor" id="id_autor" class="form-control">
<option>Seleccione</option>
<?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($item->id); ?>"
    <?php if($item->id == $post->id_autor): ?>
    selected
    <?php endif; ?>
    >
    <?php echo e($item->name); ?>

    </option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<hr>
<button class="btn btn-success">Actualizar</button>
</form>
</div>
<!-- <h1>Lista de posts</h1>
<?php echo e(dd($post)); ?>

</div> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bus209\Documents\htdocs\LaravelApi\resources\views/post/edit.blade.php ENDPATH**/ ?>