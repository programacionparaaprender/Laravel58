<link rel="stylesheet" href="../css/bootstrap.min.css">
<script src=../js/bootstrap.min.js"></script> 
<script src="../js/jquery-1.12.4.min.js"></script>

<?php /**PATH C:\Users\Bus209\Documents\htdocs\Laravel58\resources\views/bootstrap.blade.php ENDPATH**/ ?>