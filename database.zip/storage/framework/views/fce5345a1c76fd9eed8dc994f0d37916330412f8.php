<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Factura <?php echo $pedido->id; ?> </title>
  <link rel="stylesheet" href="<?php echo e(url('../css/style.css')); ?>" media="all" />
	<!-- Fonts -->
	<!--<link href='//fonts.googleapis.com/css?family=Roboto:400,300' rel='stylesheet' type='text/css'>-->
</head>
  <body>
    <header class="clearfix">
      <div id="logo">

        <img src="<?php echo url('./img/logo.jpg'); ?>"  width="50" height="50"/>
      </div>
      <div id="details" class="clearfix">
      <div id="company" class="clearfix">
        <div>Company Name</div>
        <div>455 Foggy Heights,<br /> AZ 85004, US</div>
        <div>(602) 519-0450</div>
        <div><a href="mailto:company@example.com">company@example.com</a></div>
      </div>
        <div id="client">
          <div class="to">Factura Nro: <?php echo $pedido->id; ?></div>
          <div class="date">Fecha de factura: <?php echo $pedido->created_at; ?></div>
          
          <div class="info">
              La factura esta en estado
                <?php if($pedido->idestado==1): ?>
                    EnEspera
                <?php elseif($pedido->idestado==2): ?>
                    Pagado
                <?php elseif($pedido->idestado==3): ?>
                    Enviado
                <?php elseif($pedido->idestado==4): ?>
                    Devuelto
                <?php endif; ?>
          </div>
          
          <h2 class="name">Usuario: <?php echo $user->name; ?> <?php echo $user->email; ?></h2>
          <div class="address">Dirección: <?php echo $user->email; ?></div>
          <div class="email">email: <a href="mailto:john@example.com"> <?php echo $user->email; ?></a></div>
        </div>
      </div>
    </header>
    <main>
     <table border="1" cellspacing="0" cellpadding="0">
        <thead>
          <tr>
            <th class="no" style="padding:1rem;">#</th>
            <th class="desc" style="padding:1rem;">NOMBRE</th>
            <th class="unit" style="padding:1rem;">PRECIO POR UNIDAD</th>
            <th class="qty" style="padding:1rem;">CANTIDAD</th>
            <th class="total" style="padding:1rem;">TOTAL</th>
          </tr>
        </thead>
        <tbody>
        <?php if(!empty($productos)): ?>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
            <td class="no" style="padding:1rem;"><?php echo $producto['id']; ?></td>
            <td class="desc" style="padding:1rem;"><?php echo $producto['name']; ?></td>
            <td class="unit" style="padding:1rem;"><?php echo $producto['price']; ?></td>
            <td class="qty" style="padding:1rem;"><?php echo $producto['qty']; ?></td>
            <td class="total" style="padding:1rem;"><?php echo $producto['total']; ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <h3>No tiene productos</h3>
        <?php endif; ?>
        </tbody>
        <tfoot>
          <tr>
            <td colspan="2"></td>
            <td colspan="2">TOTAL A PAGAR </td>
            <td>$ <?php echo $pedido->total; ?></td>
          </tr>
        </tfoot>
      </table>
  </body>
</html><?php /**PATH C:\Users\Bus209\Documents\htdocs\Laravel58\resources\views/pdf/factura.blade.php ENDPATH**/ ?>