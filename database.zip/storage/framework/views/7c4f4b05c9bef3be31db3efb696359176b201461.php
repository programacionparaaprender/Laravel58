<?php $__env->startSection('content'); ?>

<!-- <?php echo $libros->render(); ?> -->
    <div style="display:block;height:5rem;width:100%;"></div>
    <?php if(Session::has('creada')): ?>
<div class="alert alert-success">
    <p><?php echo e(Session::get('creada')); ?></p>
</div>
<?php endif; ?>
<div class="container-fluid">
<?php if(Auth::guest()): ?>
<h1>Productos disponibles en Programación Para Aprender </h1>
<?php else: ?>
<h1>Productos disponibles en Programación Para Aprender </h1>
<?php if(Auth::user()->admin==1): ?>
<p class="bs-component">
<a href="libros/create" class="btn btn-secondary" role="button">Crear Producto</a>
</p>
<?php endif; ?>
<?php endif; ?>
    <form class="form-inline">
    <div class="form-group" style="width:20rem;">

        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">
                    Buscar
                </span>
            </div>
            <input 
                type="text" 
                v-model="searchText"
                class="form-control" 
                :placeholder="Escribe un producto" />
        </div>
    </div>
    </form class="form">
    <div class="row">
    <?php if(Auth::guest()): ?>
    <div v-for="libro in libros | filterBy searchText in 'nombre'" class="col-xl-3 col-md-12 col-lg-6 col-sm-12 col-xs-12">
    <div class="card card-default" style="width: 18rem; height: 18rem; paddign:0.5rem;">
                            <img 
                                src="{{ libro.ruta }}" 
                                width="150px" 
                                height="150px" 
                                class="card-img-top" 
                                style="paddign:5rem;"
                                alt="...">
                            <div class="card-body">
                                <h3 class="card-title">{{ libro.nombre }}</h3> 
                                <p class="card-text" style="overflow:hidden;">{{ libro.descripcion }}</p>
        
                            </div>
                        
                        </div>
                

        </div>
    <?php elseif(Auth::user()->admin==1): ?>
        <Productos v-bind:busqueda="searchText">
        </Productos>
    <?php elseif(Auth::user()->admin<3): ?>    
    <div v-for="libro in libros | filterBy searchText in 'nombre'" class="col-xl-3 col-md-12 col-lg-6 col-sm-12 col-xs-12">
    <div class="card card-default" style="width: 18rem; height: 28rem; paddign:0.5rem;">
                        <img 
                            src="{{ libro.ruta }}" 
                            width="150px" 
                            height="150px" 
                            class="card-img-top" 
                            style="paddign:5rem;"
                            alt="...">
                        <div class="card-body">
                            <h3 class="card-title">{{ libro.nombre }}</h3> 
                            <p class="card-text" style="overflow:hidden;">{{ libro.descripcion }}</p>
                            <form action="<?php echo e(url('carrito/')); ?>" method="POST"  class="form-horizontal">
                                <input class="form-control" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" required>
                                <input class="form-control" type="hidden" name="id" value="{{ libro.id }}" required>
                                <input class="form-control" type="hidden" name="name" value="{{ libro.nombre }}" required>
                                <input class="form-control" type="hidden" name="price" value="{{ libro.precio }}" required>
                                <label>Cantidad</label>
                                <input class="form-control" type="text" name="qty" value="0" size="5" />
                                <input class="btn btn-success" role="button" type="submit" value="Comprar"/>
                            </form>
                        </div>
                    
                    </div>
            

        </div>
    <?php endif; ?>
    
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
        <script src="js/vue.js"></script>
        <script type="text/template" id="libro_template">
        </script>
        <script type="text/javascript">
/*   <Productos 
                :nombre="libro.nombre"
                :descripcion="libro.descripcion"
                :precio="libro.precio"
                :ruta="libro.ruta">
            </Productos> 
            props:['id','nombre','descripcion','precio','ruta','index']*/
            const Productos = Vue.component('productos-component',{
                template: 
                `<div v-for="libro in libros | filterBy busqueda in 'nombre'" class="col-xl-3 col-md-12 col-lg-6 col-sm-12 col-xs-12">`
    
                + `<div class="card card-default" style="width: 18rem; height: 28rem; paddign:0.5rem;">`
                + ` <img `
                +`            src="{{ libro.ruta }}" `
                + `            width="150px" `
                + `            height="150px" `
                +`            class="card-img-top" `
                + `            style="paddign:5rem;"`
                + `             alt="...">`
                + `        <div class="card-body">`
                + `            <h3 class="card-title">{{ libro.nombre }}</h3> `
                + `            <p class="card-text" style="overflow:hidden;">{{ libro.descripcion }}</p>`
                +`            <form action="<?php echo e(url('carrito/')); ?>" method="POST"  class="form-horizontal">`
                + `                <input class="form-control" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" required>`
                + `                <input class="form-control" type="hidden" name="id" value="{{ libro.id }}" required>`
                +  `                <input class="form-control" type="hidden" name="name" value="{{ libro.nombre }}" required>`
                + `                <input class="form-control" type="hidden" name="price" value="{{ libro.precio }}" required>`
                + `                <label>Cantidad</label>`
                + `          <input class="form-control" type="text" name="qty" value="0" size="5">`
                +         `          <input class="btn btn-success" role="button" type="submit" value="Comprar"/>`
                                +      `    </form>`
                            
                                +   `   <form action="carrito/destruir/{{ libro.id }}" method="GET">`
                            +  `       <div class="btn-group" role="group" aria-label="Basic example">`
                            +  `         <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" required>`
                            +         `         <a type="button" href="libros/actualizar/{{ libro.id }}" class="btn btn-primary" role="button">Editar libro</a>`
                                    +       `        <input class="btn btn-danger" role="button" type="submit" value="Eliminar"/>`
                                    +     `     </div>`
                                    +   `</form>`
                   
                            
                                + `</div>`
                    
                            + `</div>`,
                data: function() {
                    return {
                            admin: 0
                            ,libros: [
                        <?php if(sizeof($libros) > 0): ?>
                        <?php $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            { 
                                id:<?php echo e($libro->id); ?>,
                                nombre:'<?php echo e($libro->nombre); ?>',
                                descripcion:'<?php echo e($libro->descripcion); ?>',
                                precio:<?php echo e($libro->precio); ?>,
                                ruta:'<?php echo e($libro->ruta); ?>',
                                index:<?php echo e($index); ?>

                            },
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            { 
                                id:1,
                                nombre:'PHP',
                                descripcion:'PHP',
                                precio:0,
                                ruta:'img/text.png'
                            },
                        <?php endif; ?>
                        ],
                    }
                },
                async mounted(){

                },
                props: {
                    busqueda:String
                },
                methods:{

                }
            });
            new Vue({
                el: 'body',
                components:{
                    Productos
                },
                data:{
                    searchText:'',
                    admin:0
                           
                    ,libros: [
                        <?php if(sizeof($libros) > 0): ?>
                        <?php $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            { 
                                id:<?php echo e($libro->id); ?>,
                                nombre:'<?php echo e($libro->nombre); ?>',
                                descripcion:'<?php echo e($libro->descripcion); ?>',
                                precio:<?php echo e($libro->precio); ?>,
                                ruta:'<?php echo e($libro->ruta); ?>',
                                index:<?php echo e($index); ?>

                            },
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            { 
                                id:1,
                                nombre:'PHP',
                                descripcion:'PHP',
                                precio:0,
                                ruta:'img/text.png'
                            },
                        <?php endif; ?>
                        ],
                },
                filters: {

                },
                methods: {
                    indices: function (index) {
                      if (index % 4 == 0) return '<div class="row">'
                    },
                    indices2: function (index) {
                      if (index % 4 == 0) return '</div>'
                    },
                }
            });
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bus209\Documents\htdocs\LaravelGodaddy\resources\views/libros/mostrar-libros3.blade.php ENDPATH**/ ?>