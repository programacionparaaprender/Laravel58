<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
	<div class="col-md-10">
	    <div style="display:block;width:30rem;height:25rem;padding:10rem;">
			<div class="card card-default" style="width:30rem;height:10rem;padding:5rem;margin:auto; text-align:center">
				<h3>¡ Bienvenido a nuestra aplicación web !</h3>
			
			</div>
	    </div>
	</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bus209\Documents\htdocs\LaravelApiMySQL\resources\views/welcome.blade.php ENDPATH**/ ?>