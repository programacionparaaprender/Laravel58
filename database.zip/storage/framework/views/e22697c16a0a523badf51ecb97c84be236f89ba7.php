<!-- <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-theme.min.css')); ?>">

    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script> -->


<?php $__env->startSection('content'); ?>
<div class="container">
<h1>Lista de posts</h1>
<h1><a href="<?php echo e(route('post.create')); ?>" class="btn btn-primary">Crear un post</a></h1>
<table class="table table-bordered">
<thead>
    <tr>
        <th scope="col">Id</th>
        <th scope="col">Titulo</th>
        <th scope="col">Contenido</th>
        <th scope="col">Autor</th>
        <th scope="col">Operaciones</th>
        <!-- <th>Operaciones2</th> -->
    </tr>
</thead>
<tbody>
<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th scope="row"><?php echo e($item->id); ?></th>
<td><?php echo e($item->titulo); ?></td>
<td><?php echo e($item->contenido); ?></td>
<td><?php echo e($item->autor->name); ?></td>
<td>
    <div class="btn-group" role="group" aria-label="Basic example">
    <a href="<?php echo e(route('post.edit', ['id' => $item->id])); ?>" class="btn btn-warning btn-sm">Editar</a>
    <form action="<?php echo e(route('post.destroy', ['id' => $item->id])); ?>" method="post">
    <?php echo method_field('DELETE'); ?>
    <?php echo csrf_field(); ?>
    <button class="btn btn-danger btn-sm">Eliminar</button>
    </form>
    </div>
</td>
<!-- <td>
    <a href="/LaravelApi/public/post/<?php echo e($item->id); ?>/edit" class="btn btn-warning btn-sm">
         <i class="fas fa-edit"></i> Editar
    </a>
    <a href="/LaravelApi/public/post/eliminar/<?php echo e($item->id); ?>" class="btn btn-danger btn-sm">
         <i class="far fa-trash-alt"></i> Eliminar
    </a>
</td> -->
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bus209\Documents\htdocs\LaravelApi\resources\views/post/index.blade.php ENDPATH**/ ?>